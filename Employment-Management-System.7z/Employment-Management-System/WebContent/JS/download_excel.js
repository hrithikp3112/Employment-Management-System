function download_excel() {
    $.ajax({
        url: "download_excel",
        type: "get",
        data: null,
        success: function(data) {
            alert("Download Success");
        }
    })
}